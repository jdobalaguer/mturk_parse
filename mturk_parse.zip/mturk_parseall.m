function alldata = mturk_parseall(pathname)
    alldata = {};
    
    % dir files
    allfiles = dir(pathname);
    % remove directories
    
    i_allfiles = 1;
    while i_allfiles <= length(allfiles)
        if allfiles(i_allfiles).name(1)=='.'
            allfiles(i_allfiles) = [];
        else
            i_allfiles = i_allfiles+1;
        end
    end
    
    % parse files
    nb_allfiles = length(allfiles);
    for i_allfiles = 1:nb_allfiles
        % name
        filename = [pathname,filesep,allfiles(i_allfiles).name];
        % print it
        fprintf(['file "',filename,'" : %d / %d\n'],i_allfiles,nb_allfiles);
        % read and parse
        data = mturk_parsefile(filename);
        % save
        alldata{i_allfiles} = data;
    end
    
    % concatenate
    alldata = mturk_concatall(alldata);
    
    % uncell
    alldata = mturk_uncell(alldata);
end